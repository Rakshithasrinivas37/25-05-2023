#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/module.h>
#include <linux/fs.h>
#include<linux/device.h>
#include<linux/kdev_t.h>

dev_t my_dev;
static struct class *dev_class;

#define CHR_DEV_NAME "dynamic_driver"
#define CLASS_NAME "my_class"
#define DEVICE_NAME "my_device"

static int __init my_driver_init(void)
{
        alloc_chrdev_region(&my_dev, 0, 1, CHR_DEV_NAME);
        printk(KERN_INFO "MAJOR no.: %d, MINOR no.: %d\n", MAJOR(my_dev), MINOR(my_dev));

        dev_class = class_create(THIS_MODULE, CLASS_NAME);

	device_create(dev_class, NULL, my_dev, NULL, DEVICE_NAME);
        printk(KERN_INFO "Driver inserted successfully\n");

        return 0;
}

static void __exit my_driver_exit(void)
{
	device_destroy(dev_class, my_dev);
	class_destroy(dev_class);
        unregister_chrdev_region(my_dev, 1);
        printk(KERN_INFO "Driver removed successfully\n");
}


module_init(my_driver_init);
module_exit(my_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rakshitha S");
