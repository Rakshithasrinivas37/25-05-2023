#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/module.h>
#include <linux/fs.h>

#define MAJOR_NO 300
#define MINOR_NO 0

#define CHR_DEV_NAME "static_driver"

dev_t my_dev = MKDEV(MAJOR_NO, MINOR_NO);

static int __init my_driver_init(void)
{
	register_chrdev_region(my_dev, 2, CHR_DEV_NAME);
	printk(KERN_INFO "Driver registered successfully\n");
	printk(KERN_INFO "MAJOR no.: %d, MINOR no.: %d\n", MAJOR(my_dev), MINOR(my_dev));

	return 0;
}

static void __exit my_driver_exit(void)
{
	unregister_chrdev_region(my_dev, 2);
	printk(KERN_INFO "Driver unregistered successfully\n");
}


module_init(my_driver_init);
module_exit(my_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rakshitha S");
